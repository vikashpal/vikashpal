window.onload = function load() {

	console.log("hello");
}
